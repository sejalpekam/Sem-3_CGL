#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMouseEvent"
#include "QColorDialog"
#include <iostream>

using namespace std;
static QImage img(500, 500, QImage::Format_RGB888);
static QColor color, val;

const int INSIDE = 0;
const int LEFT = 1;
const int RIGHT = 2;
const int BOTTOM = 4;
const int TOP = 8;
int x_min;
int x_max;
int y_min;
int y_max;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ver = 0;
    start = true;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::dda(int x1, int y1, int x2, int y2)
{
    float dx, dy,step,xin,yin,x,y ;
       dx = x2 - x1;
       dy =y2 - y1;
       step = ((abs(dx)>abs(dy))?abs(dx):abs(dy));
       xin = dx/step;
       yin = dy/step;
       x = x1;
       y= y1;
       for(; step>0 ;step--)
       {
           img.setPixel(x,y ,color.rgb());
           x += xin;
           y += yin;
       }
       ui->label->setPixmap(QPixmap::fromImage(img));
}

void MainWindow::window()
{
    dda(x_min, y_min, x_max, y_min);
    dda(x_max, y_min, x_max, y_max);
    dda(x_max, y_max, x_min, y_max);
    dda(x_min, y_max, x_min, y_min);
}

int MainWindow::computeCode(int x, int y)
{
    int code = INSIDE;

        if (x < x_min)
            code |= LEFT;
        else if (x > x_max)
            code |= RIGHT;
        if (y < y_min)
            code |= BOTTOM;
        else if (y > y_max)
            code |= TOP;

        return code;
}

void MainWindow::cohenSutherland(int x1, int y1, int x2, int y2)
{
    int code1 = computeCode(x1, y1);
    int code2 = computeCode(x2, y2);

    bool accept = false;

    while(true){
        if((code1 == 0) && (code2 == 0)){
            accept = true;
            break;
        }
        else if(code1 & code2){
            break;
        }
        else{
            int code_out;
            int x, y;

            if(code1 != 0)
                code_out = code1;
            else
                code_out = code2;

            if(code_out & TOP){
                x = x1 + (x2 - x1) * (y_max - y1) / (y2 - y1);
                y = y_max;
            }
            else if(code_out & BOTTOM){
                x = x1 + (x2 - x1) * (y_min - y1) / (y2 - y1);
                y = y_min;
            }
            else if (code_out & RIGHT) {
                y = y1 + (y2 - y1) * (x_max - x1) / (x2 - x1);
                x = x_max;
            }
            else if (code_out & LEFT) {
                y = y1 + (y2 - y1) * (x_min - x1) / (x2 - x1);
                x = x_min;
            }

            if (code_out == code1) {
                x1 = x;
                y1 = y;
                code1 = computeCode(x1, y1);
            }
            else {
                x2 = x;
                y2 = y;
                code2 = computeCode(x2, y2);
            }
        }
    }
    if (accept) {
            dda(x1, y1, x2, y2);
        }

}

void MainWindow::mousePressEvent(QMouseEvent *ev)
{
   if (start)
   {
       int p = ev->pos().x();
       int q = ev->pos().y();
       a[ver] = p;
       b[ver] = q;

       if (ev->button()==Qt::RightButton)
       {
          start = false;
       }
       else
       {
           if (ver>0 && ver%2 != 0)
           {
               dda(a[ver], b[ver], a[ver-1], b[ver-1]);
           }
       }
       ver++;
   }
}


void MainWindow::on_select_color_clicked()
{
   color = QColorDialog::getColor();
}

void MainWindow::on_draw_window_clicked()
{
    x_min = ui->textEdit->toPlainText().toInt();
    x_max = ui->textEdit_2->toPlainText().toInt();
    y_min = ui->textEdit_3->toPlainText().toInt();
    y_max = ui->textEdit_4->toPlainText().toInt();

    window();

}

void MainWindow::on_clip_line_clicked()
{
    img = QImage(500, 500, QImage::Format_RGB888);
    window();

    for(int i = 0; i <= ver; i+=2){
        cohenSutherland(a[i], b[i], a[i+1], b[i+1] );
    }


}


void MainWindow::on_reset_clicked()
{
   img = QImage(500,500,QImage::Format_RGB888);
   ui->label->setPixmap(QPixmap::fromImage(img));
   ver = 0;
   start = true;
   x_min = 0;
   x_max = 0;
   y_min=0;
   y_max = 0;
}
