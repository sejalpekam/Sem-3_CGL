#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void mousePressEvent(QMouseEvent *ev);
    void dda(int, int, int, int);
    void window();
    int computeCode(int, int);
    void cohenSutherland(int, int, int, int);

private slots:

    void on_select_color_clicked();

    void on_draw_window_clicked();

    void on_clip_line_clicked();

    void on_reset_clicked();

private:
    Ui::MainWindow *ui;
    int ver, a[20], b[20];
    float slope[20], dx, dy;
    bool start;
};
#endif // MAINWINDOW_H
