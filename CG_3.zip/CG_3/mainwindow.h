#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "matrix.h"
#include <string>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    int ver, a[20], b[20], i, xi[20], j, temp, k;
    bool start;
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void dda(int,int,int,int,uint);
    void mousePressEvent(QMouseEvent *ev);
    void drawaxes();
    void imgreset();
    void reDisplayPolygon(Matrix);
    void translate(float, float);
    void rotate(float, int,int);
    void scale(float,float, int,int);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::MainWindow *ui;
//    int ver, a[20], b[20], i, xi[20], j, temp, k;
//    bool start;

};
#endif // MAINWINDOW_H
