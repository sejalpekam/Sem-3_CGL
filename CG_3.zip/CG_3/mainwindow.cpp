#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "matrix.h"
#include <string>
#include "QMouseEvent"
#include <iostream>
#include <QColorDialog>

#define PI 3.14159265
using namespace std;

static QImage img(700,700,QImage::Format_RGB888);
static QColor color;
static Matrix *ObjectMatrix = NULL;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    drawaxes();
    ui->label->setPixmap(QPixmap::fromImage(img));
    ver = 0;
    start = true;
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::dda(int x1, int y1, int x2, int y2, uint val)
{
    float dx, dy,step,xin,yin,x,y ;
       dx = x2 - x1;
       dy =y2 - y1;
       step = ((abs(dx)>abs(dy))?abs(dx):abs(dy));
       xin = dx/step;
       yin = dy/step;
       x = x1;
       y= y1;
       for(; step>0 ;step--)
       {
           img.setPixel(x,y ,val);
           x += xin;
           y += yin;
       }
       ui->label->setPixmap(QPixmap::fromImage(img));
}

void MainWindow::mousePressEvent(QMouseEvent *ev)
{

   if (start)
   {
       int p = ev->pos().x();
       int q = ev->pos().y();
       a[ver] = p;
       b[ver] = q;

       if (ev->button()==Qt::RightButton)
       {
          dda (a[0], b[0], a[ver-1], b[ver-1], color.rgb());
          start = false;
          ObjectMatrix = new Matrix(ver,3);
          for (i = 0; i < ver ; i++ ) {
              ObjectMatrix->setValue(i,0,a[i]);
              ObjectMatrix->setValue(i,1,b[i]);
              ObjectMatrix->setValue(i,2,1);
          }
       }
       else{
           a[ver] = p;
           b[ver] = q;
           if(ver > 0){
               dda(a[ver],b[ver],a[ver-1],b[ver-1], color.rgb());
           }
           ver++;
       }
   }

   ui->label->setPixmap(QPixmap::fromImage(img));
}

void MainWindow::drawaxes()
{
    dda(350,0,350,700,qRgb(255,255,255));
    dda(0,350,700,350, qRgb(255,255,255));
}

void MainWindow::imgreset()
{
    img = QImage(700,700,QImage::Format_RGB888);
    drawaxes();
}

void MainWindow::reDisplayPolygon(Matrix rMatrix)
{
    imgreset();
    for (i = 0; i < rMatrix.getRows() ; i++ ) {
        if(i == ver - 1){
            dda(rMatrix.getValue(i,0),rMatrix.getValue(i,1),rMatrix.getValue(0,0),rMatrix.getValue(0,1), color.rgb());
        }
        else{

            dda(rMatrix.getValue(i,0),rMatrix.getValue(i,1),rMatrix.getValue(i+1,0),rMatrix.getValue(i+1,1), color.rgb());
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(img));
}

void MainWindow::translate(float tx, float ty)
{
    Matrix tMatrix(3,3);
    tMatrix.setValue(0,0,1);
    tMatrix.setValue(1,1,1);
    tMatrix.setValue(2,0,tx);
    tMatrix.setValue(2,1,ty);
    tMatrix.setValue(2,2,1);
    Matrix rMatrix = *ObjectMatrix * tMatrix;
    reDisplayPolygon(rMatrix);
}

void MainWindow::rotate(float angle, int x, int y)
{
    Matrix tMatrix(3,3);
    float costheta = cosf(angle*PI/180.0);
    float sintheta = sinf(angle*PI/180.0);
    tMatrix.setValue(0,0,costheta);
    tMatrix.setValue(0,1,sintheta);
    tMatrix.setValue(1,0,-1 * sintheta);
    tMatrix.setValue(1,1,costheta);
    tMatrix.setValue(2,2,1);
    tMatrix.setValue(2,0,(-x*costheta)+(y*sintheta)+x);
    tMatrix.setValue(2,1,(-x*sintheta)-(y*costheta)+y);

    Matrix rMatrix = *ObjectMatrix * tMatrix;

    reDisplayPolygon(rMatrix);
}

void MainWindow::scale(float sx, float sy, int x, int y)
{
    Matrix tMatrix(3,3);
    tMatrix.setValue(0,0,sx);
    tMatrix.setValue(1,1,sy);
    tMatrix.setValue(2,2,1);

    tMatrix.setValue(2,0,(x*(1-sx)));
    tMatrix.setValue(2,1,(y*(1-sy)));

    Matrix rMatrix = *ObjectMatrix * tMatrix;

    reDisplayPolygon(rMatrix);
}




//Translate Button
void MainWindow::on_pushButton_clicked()
{
    if (ObjectMatrix != NULL){
        int tx = ui->textEdit->toPlainText().toInt();
        int ty = ui->textEdit_2->toPlainText().toInt();
        translate(tx,-1*ty);
    }

}


//Scale Button
void MainWindow::on_pushButton_2_clicked()
{
    //scaling wrt origin
    if (ObjectMatrix != NULL){
        double sx = ui->textEdit->toPlainText().toFloat();
        double sy = ui->textEdit_2->toPlainText().toFloat();
        int x = 0;
        int y = 0;
        scale(sx,sy,x+350,350-y);
    }

}

//Rotate Button
void MainWindow::on_pushButton_3_clicked()
{
    //rotation about origin
    if (ObjectMatrix != NULL){
        float angle = ui->textEdit_3->toPlainText().toFloat();
        int x = 0;
        int y = 0;
        rotate(-1*angle,x+350,350-y);
    }

}

//Color Dialog
void MainWindow::on_pushButton_4_clicked()
{
    color = QColorDialog::getColor();
}

//Reset Button
void MainWindow::on_pushButton_5_clicked()
{
    ver = 0;
    start = true;
    imgreset();
    ui->label->setPixmap(QPixmap::fromImage(img));
    if(ObjectMatrix != NULL){
        delete ObjectMatrix;
        ObjectMatrix = NULL;
    }

}
