#include "matrix.h"
#include <QDebug>


Matrix::Matrix(int rows,int cols){
    this->rows = rows;
    this->cols = cols;
    mat = new float*[rows];
    for (int i = 0; i < rows;i++){
        mat[i] = new float[cols];
    }

    for(int i = 0; i < rows; i++)
        for (int j = 0; j< cols; j++)
            mat[i][j] = 0;
}

Matrix::Matrix(const Matrix &mat2){
    this->rows = mat2.getRows();
    this->cols = mat2.getCols();
    mat = new float*[rows];
    for (int i = 0; i < rows;i++){
        mat[i] = new float[cols];
    }

    for(int i = 0; i < rows; i++)
        for (int j = 0; j< cols; j++)
            mat[i][j] = mat2.getValue(i,j);
}

int Matrix::getRows() const{
    return this->rows;
}

int Matrix::getCols() const{
    return this->cols;
}

bool Matrix::checkDimInLimit(int row,int col) const{
    return row <= this->rows && col <= this->cols;
}

//bool Matrix::checkDimEqual(int row,int col){
//    return row == this->rows && col == this->cols;
//}

bool Matrix::checkMulDim(int row){
    return row == this->cols;
}

void Matrix::setValue(int row,int col, float value){
    if(checkDimInLimit(row,col)){
        mat[row][col] = value;
    }
}

float Matrix::getValue(int row,int col) const{
    if(checkDimInLimit(row,col)){
        return mat[row][col];
    }
    return -1;
}

//Matrix Matrix::operator + (Matrix &matrix){
//    Matrix result(this->rows,this->cols);
//    if(checkDimEqual(matrix.getRows(),matrix.getCols())){
//        for(int i = 0; i < rows; i++)
//            for (int j = 0; j< cols; j++)
//                result.setValue(i,j,this->getValue(i,j)+matrix.getValue(i,j));
//    }
//    return result;

//}

//Matrix Matrix::operator - (Matrix &matrix){
//    Matrix result(this->rows,this->cols);
//    if(checkDimEqual(matrix.getRows(),matrix.getCols())){
//        for(int i = 0; i < rows; i++)
//            for (int j = 0; j< cols; j++)
//                result.setValue(i,j,this->getValue(i,j)-matrix.getValue(i,j));

//    }
//    return result;

//}

Matrix Matrix::operator * (Matrix &matrix){
    Matrix result(this->getRows(),this->cols);
    if(checkMulDim(matrix.getCols())){
        for(int i = 0; i < rows; i++){
            for (int j = 0; j< matrix.getCols(); j++){
                float sum = 0;
                float product = 0;
                for (int k = 0; k < this->cols; k++){
                    product = this->getValue(i,k) * matrix.getValue(k,j);
                    sum += product;
                }
                result.setValue(i,j,sum);
            }
        }

    }
    return result;
}

Matrix::~Matrix(){
    for (int i = 0; i < this->rows; i++)
        delete[] mat[i];

    delete[] mat;
}
