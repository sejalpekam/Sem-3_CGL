#ifndef MATRIX_H
#define MATRIX_H

class Matrix{
private:
    int rows,cols;
    float **mat;
public:
    Matrix(int rows,int cols);
    Matrix(const Matrix &mat2);

    int getRows() const;

    int getCols() const;

    bool checkDimInLimit(int row,int col) const;

//    bool checkDimEqual(int row,int col);

    bool checkMulDim(int col);

    void setValue(int row,int col, float value);

    float getValue(int row,int col) const;

//    Matrix operator + (Matrix &matrix);

//    Matrix operator - (Matrix &matrix);

    Matrix operator * (Matrix &matrix);

    ~Matrix();


};

#endif // MATRIX_H
